
<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$sql = "UPDATE contacts SET name = ?, email = ?, message = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$name, $email, $message, $id]);
header("Location: read.php");
exit();
} else {
$id = $_GET['id'];
$sql = "SELECT * FROM contacts WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id]);
$contact = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Contact</title>
</head>
<body>
<h1>Edit Contact</h1>
<form action="update.php" method="POST">
<input type="hidden" name="id" value="<?= $contact['id']; ?>">
<label for="name">Name:</label>
<input type="text" id="name" name="name" value="<?= $contact['name']; ?>" required>
<br>
<label for="email">Email:</label>
<input type="email" id="email" name="email" value="<?= $contact['email']; ?>"
required>
<br>
<label for="message">Message:</label>
<textarea id="message" name="message" required><?= $contact['message'];
?></textarea>
<br>
<button type="submit">Update</button>
</form>
<a href="read.php">Back to Contacts List</a>
</body>
</html>