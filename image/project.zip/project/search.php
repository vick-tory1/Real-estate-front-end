<?php
$zipCodeMappings = [
    "100001" => "lagos.php",
    "900001" => "abuja.php",
    "500001" => "port-harcourt.php",
    "400001" => "enugu.php",
    "101001" => "ibadan.php",
    "700001" => "kano.php",
    "800001" => "kaduna.php",
    "110001" => "maiduguri.php",
    "300001" => "benin-city.php",
    "600001" => "calabar.php",
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $zipCode = trim($_POST["zipCode"]);

    if (array_key_exists($zipCode, $zipCodeMappings)) {
        header("Location: " . $zipCodeMappings[$zipCode]);
        exit;
    } else {
        echo "<p style='color:red;'>No properties found for this zip code. Please try again.</p>";
    }
}
?>
