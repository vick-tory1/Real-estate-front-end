
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Form</title>
</head>
<body>

<?php 
/*   <form method="post" action="demo_request.php">
Name: <input type="text" name="fname">
<input type="sumbit">
</form> */
/*
#string data type: uses single or double quote 
$name = 'John Smith';
$nationality = "Nigerian";
#$title = "Dr";
$identity = "My name is $title "."$name,  I am a $nationality";
echo $identity;
var_dump($identity);// checking the data type


#integer data type
$number = 70;
$number = 60;
$sum = $number + $number;
echo $sum. "<br>";

#float data type
$float_number = 20.1;
$exponential = 2.4e3;
$float_number = $sum + $float_number ; //float data type
echo $integer_number = (string)$float_number;
var_dump($integer_number);

#NULL data type:is an empty value data type equivalent to false
$student = NULL;
if ($student == false) {
    echo "he's not a student";
}else{
   echo "he's a student<br>" ; 
}


#Array data types
$fruits = array("mango", "pineapple", "watermelon");
echo $fruits[1]. "<br>";

$cars = array('brand' => 'benz', 'color' => 'red', 'model' => 'cv23');
$cars['model'] = 'G-Wagon'; //updating and element in the array
echo $cars['model']; // to display an element

foreach ($cars as $key => $value){
    echo "$key: $value <br>" ;
} */



#Object Data type

/* class Person {
    public $name, $age, $state, $complexion;

    public function __construct($name, $age, $state, $complexion){
        $this->name = $name;
        $this->age = $age;
        $this->state = $state;
        $this->complexion = $complexion;
        
    }
    function sayeHello(){
        return "Hello my name is {$this->name} and i am {$this->age} old"."<br>". 
        "I am from: {$this->state} and {$this->complexion} in complexion";
        
    }
}

$new_person = new Person("Joshua", 20,"Lagos","Dark"); //instantiating a new object class
echo $new_person->sayeHello()."<br>"; */
#$new_person1 = new Person("James", 32);


#BOOLEAN data type
/* $student = FALSE;
if ($student){
    echo "He is a student";
} else{
    echo "He is not a student";
} */

#Resources data type: used in file handling like file upload in a form.
#$student_passport = fopen("passport.jpg", "r"); 


#Constants: when define cannot be changed in a the program again.
/* define("PI", 3.142);
echo PI ;*/



#Arithmetic Operatios

/* $a = 10;
$b = 5;
$sum = $a + $b;
$diference = $a - $b;
$product = $a * $b;
$quotient = $a/ $b;
$modulus = $a % $b;
$exponentials = $a^3;

echo "Sum of A and B: $sum"."<br>";
echo "Difference of A and B: $diference". "<br>";
echo "Product of A and B: $product."<br>";
echo "Quotient of A and B: $quotient."<br>";
echo "Modulus of A and B: $modulus."<br>";
echo "Exponential of A: $exponentials."<br>"; */

# Logic Operators
/* 
AND $$ 

OR ||

XOR */


#string concatenation: using the dot "." to join strings or variables as shown below.
#echo "He is my"." brother";


#variable Scope: This describes the limits of a variable. 
#there are three variable scopes.

#Global variable: variables declare outside a function
#local variable: Variables declared within a function
#static variable: Variables that retained their values even after exiting the function 

/* $x = 5; //Global variable declared outside the function
function myTest(){
    $y = 10; //Local variable because it's declared inside the funtion
    echo "<p>variable x inside function is: $x"; #this is global variable so it will result to error
    echo "<p>variable y inside function is: $y";
}
myTest();
echo "<p>variable x inside function is: $x";
echo "<p>variable y inside function is: $y"; #This is a local variable so it will result to error */


#Type Casting: changing a data type to another data type
/* $number = 10; //inter data type
var_dump($number); //checking the datatype of the variable
$string_var = (string)$number; //converting the integer variable to string data type 
var_dump($string_var); */



#Comparison operatiors
/* 
$a = 10;// integer
$b = "10"; //string
$a == $b; #it checks and compares the values of the two variables only
if ($a==$b){
    echo "they are equal<br>";
}else{
    echo "they are not equal<br>";
}

$a === $b; # It compares the data types and values of the two variables
if ($a===$b){
    echo "they are equal";
}else{
    echo "they are not equal";
}  */



#Class work : write a code to display the Fibonacci sequence
/* $a = 0;
$b = 1;

echo $a. ",";
echo $b.",";

for($i=0; $i<=10; $i++){
    $nextnumber = $a + $b;
    echo $nextnumber.",";
    $a = $b;
    $b = $nextnumber;

}

 */

  #Control Structures
/*   $a = 7;
if($a == 5.1 ){
     echo "A is greater";
}elseif($a >= 5 ){
    echo "A is lesser";
}else{
    echo "they are equal";
} */


#swtich statement 

/* $day = 2;
switch ($day){
    case 1:
        echo "Monday";
        break;
    case 2:
        echo "Tuesday";
        break;
    case 3:
        echo "Wednesday";
        break;
    default:
    echo "There is no day";  
} */

/* for($i =0; $i <= 10; $i++){
    echo "Number: $i <br>";
}
 */

#while loop
 /* $i = 0;
 while ($i <= 6){
    echo "A is lesser than 6<br>";
    $i++;
 } */


 #Do while loop
 /* $i = 0;
 do{
    echo "A is lesser than 6<br>";
    $i++;
 }while ($i <= 6); */


#FOREACH LOOP
 #foreach loop used to access elements in an index array
/* $contacts = ["name" ,"age","address","phoneNo"];
 foreach($contacts as $conact){
    echo "$conact <br>";
 } */

 #foreach loop used to access elements in an associative array
 /* $contacts = ["name" => "James", "age" => 24, 
            "address" => "Oshodi , Lagos", 
            "phoneNo" => "0807058857"];
 foreach($contacts as $key => $value){
    echo "$key:  $value <br>";
 } */

/*  function add ($a, $b){
    $sum = $a + $b;
    echo $sum;
 }
add(5,7);


$students = [["name" => "alice", "age" => 10], ["name" => "james", "age" => 30]];

echo $students[1]["name"]; */

#Functions

/* function add($a, $b){
    $sum = $a + $b;
    echo $sum;
}

add(4,6); */


#Arrays
#Index, Asccociative, two dimentional 
//$students = array('name','age', 'address','phonno');

$student1 = ['name' => 'Emeka','age' => 20 ,'address' => 'Oshodi, Lagos','phoneno' => "09959888868"];


/* $student_dimentional = [['name' => 'Emeka','age' => 20 ,'address' => 'Oshodi, Lagos'], 
['name' => 'Jane','age' => 24 ,'address' => '20 Olumide Str, Ikeja, Lagos']];

print_r($student_dimentional[1]['address']);
 */
/* $student1["Gender"] = "Male";
array_shift($student1);
print_r($student1);
array_splice($student1, 1, 1, "Street"); */

//print_r($student1);


/* array_unshift($student1);
print_r($students); */
//$array_sort = array(5,3,8,9,10,1,4,7,17,12,14);

//print_r($array_sort)"<br>";

/*  ksort($student1)."<br>";
print_r($student1); 

#Parsing arrays to functions
function numbers(){
    
} */
/* $x = 75;


function myFunction(){
    $GLOBALS ['x'] = 100;
    
}
myFunction();
$GLOBALS ['x'];
echo $x; */


#Super Globals 


/* $x = 10;

function MyInfo(){
    echo $x;
   $y = 5;
}

MyInfo();
echo $y;
echo $x; */


#_SERVER
// echo $_SERVER['REMOTE_ADDR'];
//echo $_SERVER['PHP_SELF'];
//echo $_SERVER['REQUEST_TIME'];
//echo $_SERVER['SCRIPT_FILENAME'];
//echo $_SERVER['REMOTE_PORT'];
//echo $_SERVER['SERVER_ADMIN'];
//echo $_SERVER['SERVER_SIGNATURE'];
//echo $_SERVER['SCRIPT_NAME']; 
/*  if($_SERVER['REQUEST_METHOD'] == "POST"){
    $name = htmlspecialchars($_REQUEST['fname']);
    if(empty($name)){
        echo "Name is empty";
    } else {
        echo $name;
    }
} ; */

#Regex: Regular Expressions

$example = "there rains are staining in people in SpaIN";
$xpressions = "/staining/i";
//echo preg_match($example, $xpressions);

/* if(!preg_match($example, $expressions)){
    echo "this is good";
}
 */

/* preg_match_all();
echo preg_replace($example, "Staining", $xpressions);
filter_var();
 */

/* $numbers = [2,9,10,20,1,5,8];

print_r($numbers)."<br>";

sort($numbers);
print_r($numbers);

rsort($numbers);
print_r($numbers); */
 


/* $word = ["mad"];
if($word == rsort($word)){
    echo "This is a palindrome";
}else {
    echo "it is not a palindrome";
} */






?>
</body>
</html>

