<?php

$name = filter_var($name, FILTER_SANITIZE_STRING);
$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$message = filter_var($message, SANITIZE_STRING);

if (empty($_POST['name'])){
    echo "Name is required";
}

if(!filter_var($email, FILTER_SANITIZE_EMAIL)){
    echo "Email is required";
}

if(!filter_var($message, FILTER_SANITIZE_STRING)){
    echo "Message is required";
}


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contact_form_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
    die("Connection failed:", $conn->connect_error); 
}


If($_SERVER["REQUEST_METHOD"] == "POST"){
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));
    $errors = [];

//validate name
    if(empty($name)){
        $errors[] = "Name is required";
    }elseif (!filter_var($name, FILTER_SANITIZE_STRING)){
        $errors[] = "only letters and white space allowed in name."
    }

    //Validate email

if(empty($email)){
    $errors = "Email is required";
}elseif(!filter_var($email, FILTER_SANITIZE_EMAIL)){
    $errors[] = "Invalid email format";
}

if(empty($message)){
    $errors[] = "Message is required"
}

//if no errors, insert data into database
if (empty($errors)){
    $sql_stament =$conn->prepare("INSERT INTO messages(name, email, message)VALUES(???)");
    $sql_stament->bind_param("sss", $name, $email, $message);

    if($sql_stament->execute()){
        echo "Thank you, $name. ";
    }else{
        echo "Error: ".$sql_stament->error;
    }
    $sql_stament->$close();
}else {
    foreach($errors as $error){
        echo "<p>$error</p>";
    }
}else{
    echo "Invalid submission";
}

$conn-.close();

}




?>