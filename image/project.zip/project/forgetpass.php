<?php
// Database connection
$host = 'localhost';
$dbname = 'real_estate1.db';
$user = 'your_username';
$pass = 'your_password';

try {
    $pdo = new PDO("mysql:host=$host;real_estate1.db=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => "error", "message" => "Invalid email address."]);
        exit;
    }

    // Check if email exists in the database
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(["status" => "error", "message" => "Email not found."]);
        exit;
    }

    // Generate a reset token and expiry time
    $resetToken = bin2hex(random_bytes(16)); // Random token
    $expiryTime = date('Y-m-d H:i:s', strtotime('+1 hour'));

    // Store the token and expiry time in the database
    $stmt = $pdo->prepare("UPDATE users SET reset_token = :reset_token, token_expiry = :token_expiry WHERE email = :email");
    $stmt->execute([
        'reset_token' => $resetToken,
        'token_expiry' => $expiryTime,
        'email' => $email,
    ]);

    // Create the password reset link
    $resetLink = "http://yourdomain.com/reset_password.php?token=$resetToken";

    // Send the email (using PHP's mail function or an external service)
    $subject = "Password Reset Request";
    $message = "Click the link below to reset your password:\n\n$resetLink\n\nThis link will expire in 1 hour.";
    $headers = "From: no-reply@yourdomain.com";

    if (mail($email, $subject, $message, $headers)) {
        echo json_encode(["status" => "success", "message" => "Password reset link has been sent to your email."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to send email."]);
    }
}
?>
