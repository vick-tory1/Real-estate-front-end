<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['token'])) {
    $resetToken = $_GET['token'];

    // Validate token
    $stmt = $pdo->prepare("SELECT id FROM users WHERE reset_token = :reset_token AND token_expiry > NOW()");
    $stmt->execute(['reset_token' => $resetToken]);
    $user = $stmt->fetch();

    if (!$user) {
        die("Invalid or expired token.");
    }

    // Show the reset password form (HTML)
    echo '<form method="POST" action="reset_password.php">
            <input type="hidden" name="token" value="' . htmlspecialchars($resetToken) . '">
            <label for="password">New Password</label>
            <input type="password" name="password" required>
            <button type="submit">Reset Password</button>
          </form>';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle password reset
    $resetToken = $_POST['token'];
    $newPassword = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Validate token again
    $stmt = $pdo->prepare("SELECT id FROM users WHERE reset_token = :reset_token AND token_expiry > NOW()");
    $stmt->execute(['reset_token' => $resetToken]);
    $user = $stmt->fetch();

    if (!$user) {
        die("Invalid or expired token.");
    }

    // Update the password and clear the reset token
    $stmt = $pdo->prepare("UPDATE users SET reset_token = NULL, token_expiry = NULL, password = :password WHERE reset_token = :reset_token");
    $stmt->execute([
        'password' => $newPassword,
        'reset_token' => $resetToken,
    ]);

    echo "Your password has been successfully reset.";
}
?>
