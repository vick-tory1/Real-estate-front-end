<?php

//start_session();

//session_destroy();
//unset_session();

//exit();



require 'db.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$message = trim($_POST['message']);
    
$sql = "INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->execute([$name, $email, $message]);
header("Location: read.php");
exit();
}
?>