<?php
$servername = "localhost";
$fullname = "root";
$email = "root";
$password = "";
$dbname = "main_real_estate";

// try {
// $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username,a
// $password);` 
// $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// } catch(PDOException $e) {
// echo "Connection failed: " . $e->getMessage();
// }


$conn = new mysqli($servername, $fullname, $email, $password, $dbname);

if ($conn->connect_error) {
    die("connection failed:" . $conn->connect_error);
}
// require 'connect.php';

#Registration
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    

    if (!empty($fullname) && !empty($email) && !empty($password)) {
        $stm = $conn->prepare("SELECT id FROM user_form3 WHERE fullname = ?");
        $stm = $conn->prepare("SELECT id FROM user_form3 WHERE email = ?");
        $stm->bind_param("s", $fullname);
        $stm->bind_param("s", $email);
        $stm->execute();
        $stm->store_result();

        if ($stm->num_rows > 0) {
            echo "fullname is already taken";
        } else {

            
        if ($stm->num_rows > 0) {
            echo "email is already taken";
        } else {

            //hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            // $hashed_password = md5($password);

            //Insert new user into the database
            $stm = $conn->prepare("INSERT INTO user_form3 (fullname, email, password) VALUES (?,?,?)");
            $stm->bind_param("sss",  $fullname,$email, $password);

            if ($stm->execute()) {
                echo "Registration was successful";
            } else {
                echo "Something went wrong";
            }
        }
        }
        $stm->close();
    }
}
$conn->close();

// try {
// $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username,
// $password);` 
// $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// } catch(PDOException $e) {
// echo "Connection failed: " . $e->getMessage();
// }