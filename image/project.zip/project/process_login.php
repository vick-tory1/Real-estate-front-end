<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contact_form_db";


$conn = new mysqli($servername,$username, $password, $dbname);

if($conn->connect_error){
    die("connection failed:". $conn->connect_error);

}


#Registration 
if($_SERVER["REQUEST_METHOD"] =="POST"){
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
 

    //if(!empty($username) && !empty($password)){
        $stm = $conn->prepare("SELECT id, username, password FROM users WHERE  username = ?");
        $stm->bind_param("s", $username);
        $stm->execute();
        $stm->store_result();

    if($stm->num_rows > 0){
            $stm->bind_result($id, $username, $hashed_password);
            $stm->fetch();    

            if(password_verify($password, $hashed_password)){
               // session_start();

                $_SESSION["loggedin"] = TRUE;
                $_SESSION["id"] = $id;
                $_SESSION["username"] = $username;
                header("location: responsive.html");
            }else{

                //hash the password
            echo "Invalid password";
        }

    }else{
        //hash the password
    echo "No account found with that username";
    }
$stm->close();
}
$conn->close();




/* session_start();
session_destroy();
header('location: login.html');
 exit(); */






/* 
try {
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
echo "Connection failed: " . $e->getMessage();
} */
?>
