<?php
require 'db2.php';
$sql = "SELECT * FROM user_form3";
$stmt = $conn->query($sql);
$user_form3 = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contacts List</title>

</head>
<body>
<h1>Contacts List</h1>
<a href="index.html"></a><!-- Add New Contact link-->
<table border="1">
<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Message</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php foreach ($user_form3 as $user_form33): ?>
<tr>
<td><?= $contact['id']; ?></td>
<td><?= $contact['name']; ?></td>
<td><?= $contact['email']; ?></td>
<td><?= $contact['message']; ?></td>
<td>
<a href="update.php?id=<?= $contact['id']; ?>">Edit</a>
<a href="delete.php?id=<?= $contact['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</body>
</html>