<?php
$zipCodeMappings = [
    "100001" => "lagos.php",         // Lagos
    "900001" => "abuja.php",         // Abuja (FCT)
    "500001" => "port-harcourt.php", // Rivers
    "400001" => "enugu.php",         // Enugu
    "101001" => "ibadan.php",        // Oyo
    "700001" => "kano.php",          // Kano
    "800001" => "kaduna.php",        // Kaduna
    "110001" => "maiduguri.php",     // Borno
    "300001" => "benin-city.php",    // Edo
    "600001" => "calabar.php",       // Cross River
];
?>
