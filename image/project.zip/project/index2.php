<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
</head>
<body>
    <h1>Contact Form</h1>
    <form action="db.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="username"required>
        <br>
        <label for="email">Email:</label>
        <input type="text" id="email" name="password" required>
        <br>
        <label for="message">Message:</label>
        <textarea id="message" name="message" required></textarea>
        <br>
        <button type="submit">Submit</button>
    </form>
    <h2>Contacts List</h2>
    <a href="read.php">View Contacts</a>
    
</body>
</html>

