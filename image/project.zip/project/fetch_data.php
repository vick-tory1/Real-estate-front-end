<?php
include 'db_config.php';

if ($_GET['type'] == 'properties') {
    $query = "SELECT * FROM properties";
    $result = $conn->query($query);

    $properties = [];
    while ($row = $result->fetch_assoc()) {
        $properties[] = $row;
    }
    echo json_encode($properties);
}

if ($_GET['type'] == 'agents') {
    $query = "SELECT * FROM agents";
    $result = $conn->query($query);

    $agents = [];
    while ($row = $result->fetch_assoc()) {
        $agents[] = $row;
    }
    echo json_encode($agents);
}
?>
